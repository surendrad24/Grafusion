# Security Policy

Do not publish suspected vulnerabilities in a public issue.

Before releasing this repository publicly, add the approved private security-reporting email or disclosure form here. Include affected versions, reproduction steps, impact, and any suggested remediation in the report.

Never commit API keys, tokens, credentials, private endpoints, customer data, or production configuration.
