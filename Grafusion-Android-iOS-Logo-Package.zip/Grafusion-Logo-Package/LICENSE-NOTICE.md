# License Notice

Copyright © 2026 Fusionlancers Technologies Pvt. Ltd. All rights reserved.

This package does not assign an open-source software license. Add the company-approved license before distributing source code, accepting external contributions, or publishing releases.
