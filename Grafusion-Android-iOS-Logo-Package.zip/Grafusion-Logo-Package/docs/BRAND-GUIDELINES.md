# Grafusion Brand Guidelines

## Brand idea

The **Data Fusion Node** combines three ideas:

- A geometric **G** for Grafusion
- A smooth orbit for convergence and fusion
- A sharp data path with connected nodes for metrics and visualization

The mark is original and must not be combined with, traced from, or presented as the official Grafana logo.

## Colors

| Name | Hex | Suggested use |
|---|---|---|
| Fusion Navy | `#0B1739` | Primary background, wordmark |
| Fusion Blue | `#142B5F` | Gradient and secondary background |
| Energy Orange | `#FF8A00` | Primary energy accent |
| Data Purple | `#7C3AED` | Secondary data accent |
| White | `#FFFFFF` | Dark-background contrast |
| Soft White | `#EEF2FF` | Supporting background |

## Typography

Recommended typeface: **Inter**.

- Wordmark: Inter Semi Bold
- Headings: Inter Semi Bold or Bold
- Body: Inter Regular

Font files are not included in this package. Use an appropriately licensed local or webfont source.

## Clear space

Keep clear space equal to at least one metric-node diameter around the mark. Do not place the mark against visually noisy backgrounds.

## Minimum sizes

- Digital mark: 24 px minimum
- Horizontal wordmark: 120 px minimum width
- Print mark: 8 mm minimum

## Do not

- Stretch, skew, or rotate the mark
- Change individual node positions
- Add text inside the app icon
- Add platform-rounded corners to the iOS master icon
- Place the colored mark on low-contrast backgrounds
- Use the official Grafana swirl as part of the Grafusion identity
