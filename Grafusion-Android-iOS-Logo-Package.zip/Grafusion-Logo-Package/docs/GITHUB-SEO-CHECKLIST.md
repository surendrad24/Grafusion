# GitHub Discoverability Checklist

- Repository name: `grafusion`
- Add the one-sentence description provided in the main README.
- Add focused repository topics; avoid irrelevant or repeated tags.
- Upload `social/github-social-preview-1280x640.jpg` under repository social preview settings.
- Keep the primary keyword phrase in the H1, opening paragraph, and image alt text naturally.
- Add genuine screenshots with descriptive alt text.
- Link releases, documentation, security policy, and contribution guidance.
- Replace every `YOUR_...` placeholder before publishing.
- Keep package metadata, supported Grafana version, and mobile build requirements accurate.
- Avoid keyword stuffing; prioritize clear product terminology and real use cases.
