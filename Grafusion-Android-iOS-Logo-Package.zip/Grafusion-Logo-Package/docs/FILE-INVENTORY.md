# Package Inventory

## Brand source
- Editable SVG master icon, marks, and wordmarks
- PDF and EPS exports where supported
- 1024 px transparent PNG marks and master app icon

## Android
- Legacy launcher density assets
- Adaptive foreground/background layers
- Monochrome themed-icon layer
- Round icons
- Play Store icon and feature graphic

## iOS
- Modern universal app icon catalog with base, dark, and tinted appearances
- Classic iPhone/iPad asset catalog
- Standalone App Store marketing icon

## Web
- Multi-size favicon ICO
- PNG favicons
- Apple touch icon
- PWA icons and web manifest

## Social
- GitHub social preview
- LinkedIn banner
- Square profile avatar

## Documentation
- SEO-oriented GitHub README
- Brand guidelines
- Android and iOS integration notes
- Repository metadata recommendations
