# Grafusion iOS App Icons

Two integration options are included:

1. `modern-universal-assets/` — base, dark, and tinted 1024 × 1024 assets for recent Xcode/iOS workflows.
2. `classic-assets-catalog/` — the full traditional iPhone/iPad size matrix for broader project compatibility.

## Install

- Copy the preferred `Assets.xcassets/AppIcon.appiconset` into your Xcode project.
- In the target settings, set **App Icons Source** to `AppIcon`.
- Do not add rounded corners; iOS applies the platform mask.
- The supplied raster icons are opaque PNG files.

The package also includes `AppStore-Marketing-1024.png` as a standalone store asset.
