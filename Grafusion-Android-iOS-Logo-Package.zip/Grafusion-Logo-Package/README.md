<p align="center">
  <img src="assets/brand/png/grafusion-wordmark-horizontal.png" alt="Grafusion logo — Grafana data visualization and data integration app" width="520">
</p>

<h1 align="center">Grafusion — Grafana Data Visualization & Data Integration App</h1>

<p align="center">
  Fuse complex data streams into clear, unified Grafana dashboards for monitoring, metrics, and operational insights.
</p>

<p align="center">
  <img alt="Android" src="https://img.shields.io/badge/Android-supported-3DDC84?logo=android&logoColor=white">
  <img alt="iOS" src="https://img.shields.io/badge/iOS-supported-000000?logo=apple&logoColor=white">
  <img alt="Grafana integration" src="https://img.shields.io/badge/Grafana-integration-F46800?logo=grafana&logoColor=white">
  <img alt="Project status" src="https://img.shields.io/badge/status-active-2563EB">
</p>

## Overview

**Grafusion** is a data visualization and data integration application developed by **Fusionlancers Technologies Pvt. Ltd.** It is designed to combine multiple data streams and present them through intuitive Grafana dashboards.

The project focuses on unified monitoring, real-time metrics, dashboard clarity, scalable data views, and consistent product branding across Android, iOS, web, GitHub, and Grafana-related surfaces.

## Key features

- **Unified data views** — bring disparate data sources into a single dashboard experience.
- **Grafana-focused visualization** — organize complex metrics into readable monitoring views.
- **Real-time monitoring orientation** — support operational visibility and faster analysis.
- **Scalable presentation** — maintain clarity as data volume and dashboard usage grow.
- **Cross-platform branding** — production-ready visual assets for Android, iOS, web, and repository documentation.

## Common use cases

Grafusion can be positioned for:

- Grafana dashboard integration
- Data source consolidation
- Infrastructure and application monitoring
- Business metrics visualization
- Real-time operational dashboards
- Mobile access to unified analytics

## Platforms

| Platform | Status | Branding assets |
|---|---:|---|
| Android | Supported | Adaptive, monochrome, round, legacy, Play Store |
| iOS / iPadOS | Supported | Modern universal and classic asset catalogs |
| Web / PWA | Supported | Favicon, touch icon, manifest icons |
| GitHub | Supported | README wordmark and social preview |

## Getting started

> Replace the placeholders in this section with the final repository and build instructions before publishing.

```bash
# Clone the repository
git clone https://github.com/YOUR-ORGANIZATION/grafusion.git
cd grafusion

# Install project dependencies
YOUR_INSTALL_COMMAND

# Start the development environment
YOUR_START_COMMAND
```

## Android app icon integration

Copy the contents of:

```text
android/app/src/main/res/
```

into the Android app module. Ensure the Android manifest references `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`.

## iOS app icon integration

Choose one supplied asset catalog:

```text
ios/modern-universal-assets/Assets.xcassets/AppIcon.appiconset/
ios/classic-assets-catalog/Assets.xcassets/AppIcon.appiconset/
```

Add the selected catalog to the Xcode project and assign `AppIcon` as the target’s app icon source.

## Screenshots

Add genuine product screenshots or short GIF demonstrations here. Descriptive alt text should explain the dashboard, data source, and user outcome represented in each image.

```markdown
![Grafusion unified Grafana dashboard showing real-time metrics](docs/images/dashboard-screenshot.png)
```

## Repository discoverability

Recommended GitHub repository description:

> Grafusion is a Grafana data visualization and data integration app for combining multiple data streams into clear, unified, real-time dashboards.

Recommended GitHub topics:

```text
grafana, data-visualization, data-integration, dashboards, observability,
monitoring, metrics, analytics, android, ios, mobile-app
```

Use `social/github-social-preview-1280x640.jpg` as the repository social preview.

## Branding

The Grafusion identity uses an original **Data Fusion Node** symbol: a geometric “G” combines a rounded orbit with a sharp data path and connected metric nodes. The identity does not reproduce the official Grafana logo.

Primary colors:

- Fusion Navy — `#0B1739`
- Fusion Blue — `#142B5F`
- Energy Orange — `#FF8A00`
- Data Purple — `#7C3AED`
- White — `#FFFFFF`

See [`docs/BRAND-GUIDELINES.md`](docs/BRAND-GUIDELINES.md) for usage guidance.

## Contributing

Contributions should include a clear issue or use case, focused changes, testing notes, and updated documentation when behavior changes. See [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Security

Do not commit credentials, API keys, tokens, private endpoints, or production data. Report security concerns privately using the process in [`SECURITY.md`](SECURITY.md).

## Trademark notice

Grafana is a third-party trademark. The Grafusion name and original artwork do not imply endorsement by or affiliation with the Grafana trademark owner.

## License

Copyright © 2026 **Fusionlancers Technologies Pvt. Ltd.** All rights reserved.

Add the project’s approved software license before public distribution or accepting external contributions.

## Company

Developed by **Fusionlancers Technologies Pvt. Ltd.**

- Website: https://fusionlancers.com/
