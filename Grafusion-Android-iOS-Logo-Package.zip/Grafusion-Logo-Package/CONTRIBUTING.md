# Contributing to Grafusion

1. Open or reference an issue that explains the problem or proposed improvement.
2. Keep changes focused and document behavior changes.
3. Add or update tests when the project contains a relevant test suite.
4. Confirm that no secrets, customer data, private endpoints, or generated build artifacts are committed.
5. Submit a pull request with setup notes, screenshots for visual changes, and validation steps.

External contribution terms should be finalized together with the project license before public contributions are accepted.
