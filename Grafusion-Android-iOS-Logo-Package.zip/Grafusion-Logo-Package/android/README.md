# Grafusion Android App Icons

The `app/src/main/res/` folder is ready to merge into an Android Studio project.

## Included

- Legacy launcher icons from `mdpi` through `xxxhdpi`
- Round launcher icons
- Adaptive foreground and background layers
- Monochrome layer for supported themed-icon launchers
- Google Play 512 × 512 icon
- Google Play feature graphic, 1024 × 500

## Install

1. Merge `app/src/main/res/` into the app module.
2. Confirm the application manifest uses:

```xml
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
```

3. Preview circle, squircle, rounded-square, and themed-icon masks in Android Studio.
